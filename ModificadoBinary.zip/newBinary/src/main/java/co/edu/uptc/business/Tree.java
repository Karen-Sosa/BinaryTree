package co.edu.uptc.business;

import co.edu.uptc.list.DoublyLinked;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Tree {
    private static final String QUESTION = "PREGUNTA";
    private static final String CHARACTER = "PERSONAJE";

    private TreeNode root;

    public Tree(){
        root = null;
    }

    public DoublyLinked<String> preOrder(){
        DoublyLinked<String> result = new DoublyLinked<>();
        preOrder(root, result);
        return result;
    }

    private void preOrder(TreeNode node, DoublyLinked<String> result){
        if(node == null){
            return;
        }
        result.addLast(node.getData());
        preOrder(node.getLeft(), result);
        preOrder(node.getRight(), result);
    }

    public DoublyLinked<String> inOrder(){
        DoublyLinked<String> result = new DoublyLinked<>();
        inOrder(root, result);
        return result;
    }

    private void inOrder(TreeNode node, DoublyLinked<String> result){
        if(node == null){
            return;
        }
        inOrder(node.getLeft(), result);
        result.addLast(node.getData());
        inOrder(node.getRight(), result);
    }

    public DoublyLinked<String> postOrder(){
        DoublyLinked<String> result = new DoublyLinked<>();
        postOrder(root, result);
        return result;
    }

    private void postOrder(TreeNode node, DoublyLinked<String> result){
        if(node == null){
            return;
        }
        postOrder(node.getLeft(), result);
        postOrder(node.getRight(), result);
        result.addLast(node.getData());
    }

    public void load(DoublyLinked<String> data){
        TreeNode newRoot = buildTree(data);
        if (!data.isEmpty()) {
            throw new IllegalArgumentException("El registro tiene contenido sobrante.");
        }
        root = newRoot;
    }

    public TreeNode buildTree(DoublyLinked<String> data){
        if(data.isEmpty()){
            throw new IllegalArgumentException("El archivo contenedor del  árbol está vacío.");
        }

        String[] parts = parseLine(data.removeFirst());
        TreeNode node = new TreeNode(parts[1]);
        if (parts[0].equals(QUESTION)){
            node.setLeft(buildTree(data));
            node.setRight(buildTree(data));
        }
        return node;
    }

    private String[] parseLine(String line){
        String[] parts = line.split(",", 2);
        boolean valid = parts.length == 2 && !parts[1].isBlank() && (parts[0].trim().equals(QUESTION) || parts[0].trim().equals(CHARACTER));
        if(!valid){
            throw new IllegalArgumentException("Error en la lectura de: " + line);
        }
        return new String[]{parts[0].trim(), parts[1].trim()};
    }

    public void replaceNode(TreeNode oldNode, TreeNode newNode) {
        if (root == oldNode) {
            root = newNode;
            return;
        }
        replaceNode(root, oldNode, newNode);
    }

    private boolean replaceNode(TreeNode current, TreeNode oldNode, TreeNode newNode) {
        if (current == null) {
            return false;
        }
        return replaceChild(current, oldNode, newNode) || replaceNode(current.getLeft(), oldNode, newNode) || replaceNode(current.getRight(), oldNode, newNode);
    }

    private boolean replaceChild(TreeNode parent, TreeNode oldNode, TreeNode newNode) {
        if (parent.getLeft() == oldNode) {
            parent.setLeft(newNode);
            return true;
        }
        if (parent.getRight() == oldNode) {
            parent.setRight(newNode);
            return true;
        }
        return false;
    }

    public DoublyLinked<String> draw() {
        DoublyLinked<String> lines = new DoublyLinked<>();
        draw(root, "", "", lines);
        return lines;
    }

    private void draw(TreeNode node, String prefix, String childPrefix, DoublyLinked<String> lines) {
        if (node == null) {
            return;
        }
        lines.addLast(prefix + node.getData());
        draw(node.getLeft(), childPrefix + "|-- Sí: ", childPrefix + "|   ", lines);
        draw(node.getRight(), childPrefix + "`-- No: ", childPrefix + "    ", lines);
    }

    public DoublyLinked<String> serialize() {
        DoublyLinked<String> lines = new DoublyLinked<>();
        serialize(root, lines);
        return lines;
    }

    private void serialize(TreeNode node, DoublyLinked<String> lines) {
        if (node == null) {
            return;
        }
        String type = node.isLeaf() ? CHARACTER : QUESTION;
        lines.addLast(type + "," + node.getData());
        serialize(node.getLeft(), lines);
        serialize(node.getRight(), lines);
    }

    public int countCharacters() {
        return countCharacters(root);
    }

    private int countCharacters(TreeNode node) {
        if (node == null) {
            return 0;
        }
        if (node.isLeaf()) {
            return 1;
        }
        return countCharacters(node.getLeft()) + countCharacters(node.getRight());
    }

    public int countQuestions() {
        return countQuestions(root);
    }

    private int countQuestions(TreeNode node) {
        if (node == null || node.isLeaf()) {
            return 0;
        }
        return 1 + countQuestions(node.getLeft()) + countQuestions(node.getRight());
    }

    public boolean isEmpty() {
        return root == null;
    }

    //adicionales:
    private TreeNode findNode(TreeNode node, String text, boolean onlyLeaves) {
        if (node == null || text == null) {
            return null;
        }
        if (node.isLeaf() == onlyLeaves && node.getData().equalsIgnoreCase(text.trim())) {
            return node;
        }
        TreeNode found = findNode(node.getLeft(), text, onlyLeaves);
        return found != null ? found : findNode(node.getRight(), text, onlyLeaves);
    }

    public boolean modifyQuestion(String oldQuestion, String newQuestion) {
        TreeNode node = findNode(root, oldQuestion, false);
        if (node == null || newQuestion == null || newQuestion.isBlank() || newQuestion.contains(",")) {
            return false;
        }
        node.setData(newQuestion.trim());
        return true;
    }

    public DoublyLinked<String> searchPath(String character) {
        DoublyLinked<String> path = new DoublyLinked<>();
        TreeNode target = findNode(root, character, true);
        if (target == null) {
            return path;
        }
        TreeNode node = root;
        while (!node.isLeaf()) {
            boolean goLeft = contains(node.getLeft(), target);
            path.addLast(node.getData() + " -> " + (goLeft ? "Sí" : "No"));
            node = goLeft ? node.getLeft() : node.getRight();
        }
        path.addLast("PERSONAJE: " + node.getData());
        return path;
    }

    private boolean contains(TreeNode node, TreeNode target) {
        if (node == null) {
            return false;
        }
        return node == target || contains(node.getLeft(), target) || contains(node.getRight(), target);
    }

    public int height() {
        return height(root);
    }

    private int height(TreeNode node) {
        if (node == null) {
            return -1;
        }
        return 1 + Math.max(height(node.getLeft()), height(node.getRight()));
    }

    public int depth(String character) {
        TreeNode target = findNode(root, character, true);
        return target == null ? -1 : depth(root, target);
    }

    private int depth(TreeNode node, TreeNode target) {
        if (node == target) {
            return 0;
        }
        return 1 + (contains(node.getLeft(), target) ? depth(node.getLeft(), target) : depth(node.getRight(), target));
    }

    public boolean deleteCharacter(String character) {
        TreeNode target = findNode(root, character, true);
        if (target == null || target == root) {
            return false;
        }
        TreeNode parent = findParent(root, target);
        TreeNode sibling = parent.getLeft() == target ? parent.getRight() : parent.getLeft();
        replaceNode(parent, sibling);
        return true;
    }

    private TreeNode findParent(TreeNode node, TreeNode target) {
        if (node == null || node.isLeaf()) {
            return null;
        }
        if (node.getLeft() == target || node.getRight() == target) {
            return node;
        }
        TreeNode found = findParent(node.getLeft(), target);
        return found != null ? found : findParent(node.getRight(), target);
    }

    public Tree deepCopy() {
        Tree copy = new Tree();
        copy.setRoot(deepCopy(root));
        return copy;
    }

    private TreeNode deepCopy(TreeNode node) {
        if (node == null) {
            return null;
        }
        TreeNode copy = new TreeNode(node.getData());
        copy.setLeft(deepCopy(node.getLeft()));
        copy.setRight(deepCopy(node.getRight()));
        return copy;
    }
}
