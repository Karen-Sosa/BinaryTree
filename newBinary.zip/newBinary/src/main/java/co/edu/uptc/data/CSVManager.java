package co.edu.uptc.data;

import co.edu.uptc.list.DoublyLinked;
import co.edu.uptc.list.ListNode;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

public class CSVManager {

    private final String CONFIG = "config.properties";

    private final String path;
    private final String defaultResource;

    public CSVManager(){
        Properties config = loadConfig();
        this.path = config.getProperty("tree.path");
        this.defaultResource = config.getProperty("tree.default");
    }

    private Properties loadConfig() {
        Properties properties = new Properties();
        try (InputStream input = CSVManager.class.getClassLoader().getResourceAsStream(CONFIG)) {
            if (input != null) {
                properties.load(input);
            }
        } catch (IOException e) {
            // Se usan los valores por defecto.
        }
        return properties;
    }

    private DoublyLinked<String> addToList() {
        DoublyLinked<String> data = new DoublyLinked<>();
        try (BufferedReader br = Files.newBufferedReader(Path.of(path), StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.isEmpty() && !line.startsWith("#")) {
                    data.addLast(line);
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException("No se pudo leer el archivo " + path, e);
        }
        return data;
    }

    public void createExternalFile(){
        try (InputStream input = CSVManager.class.getClassLoader().getResourceAsStream(defaultResource)) {
            if (input == null) {
                throw new FileNotFoundException("No existe el archivo por defecto: " + defaultResource);
            }
            existDirectory();
            Files.copy(input, Path.of(path), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new UncheckedIOException("No se pudo crear el archivo " + path, e);
        }
    }

    private void existDirectory() throws IOException {
        Path parent = Path.of(path).toAbsolutePath().getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
    }


    public void write(DoublyLinked<String> data) {
        try {
            existDirectory();
            writeLines(data);
        } catch (IOException e) {
            throw new UncheckedIOException("No se pudo guardar el archivo " + path, e);
        }
    }

    private void writeLines(DoublyLinked<String> data) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Path.of(path), StandardCharsets.UTF_8)) {
            ListNode<String> current = data.getHead();
            while (current != null) {
                bw.write(current.getData());
                bw.newLine();
                current = current.getNext();
            }
        }
    }

    public DoublyLinked<String> reset() {
        createExternalFile();
        return addToList();
    }

    public DoublyLinked<String> read() {
        if (Files.notExists(Path.of(path))) {
            createExternalFile();
        }
        return addToList();
    }
}
