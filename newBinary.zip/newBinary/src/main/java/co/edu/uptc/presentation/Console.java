package co.edu.uptc.presentation;

import co.edu.uptc.business.Manager;
import co.edu.uptc.business.Tree;
import co.edu.uptc.business.TreeNode;
import co.edu.uptc.data.CSVManager;
import co.edu.uptc.list.DoublyLinked;
import co.edu.uptc.list.ListNode;

import java.io.UncheckedIOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Console {
    private final Scanner sc;
    private final Tree tree;
    private final Manager game;
    private final CSVManager csvManager;

    public Console (Tree tree, CSVManager csvManager){
        this.sc = new Scanner(System.in);
        this.tree = tree;
        this.csvManager = csvManager;
        this.game = new Manager(tree);
    }

    public void start() {
        loadTree();
        try {
            menu();
        } catch (NoSuchElementException e) {
            showMessage("\nEntrada finalizada.");
        }
        saveTree();
    }

    public void loadTree(){
        try{
            tree.load(csvManager.read());
        }catch (IllegalArgumentException e){
            showMessage("Archivo del árbol inválido (" + e.getMessage() + ") El árbol por defecto será restaurado.");

        }
    }

    public void menu() {
        int option;
        do {
            showMenu();
            option = readInt();
            handleOption(option);
        } while (option != 0);
    }

    private void showMenu() {
        showMessage("\nBienvenido a Adivina tu personaje\n"
                + "OPCIONES--->\n"
                + "1. Iniciar sesión de juego\n"
                + "2. Mostrar el árbol\n"
                + "3. Mostrar la cantidad de soluciones e interrogantes\n"
                + "4. Reiniciar a la estructura inicial\n"
                + "0. Salir");
    }

    private void handleOption(int option) {
        switch (option) {
            case 1:
                playGame();
                break;
            case 2:
                showTree();
                break;
            case 3:
                showStatistics();
                break;
            case 4:
                resetTree();
                break;
            case 0:
                showMessage("Te veo luego :)");
                break;
            default:
                showMessage("Opción inválida. Intente nuevamente.");
        }
    }

    private void playGame(){
        if (tree.isEmpty()) {
            showMessage("No existe  el juego (sin datos).");
            return;
        }
        showMessage("\nPiensa en un personaje.");
        game.start();
        while (!game.isCharacter()) {
            showMessage("\n" + game.getCurrentNode().getData());
            game.answer(readYesNo());
        }
        guess();
    }

    private void guess(){
        showMessage("\n¿Es un " + game.getCurrentNode().getData() + "?");
        if (readYesNo()) {
            showMessage("\n¡Lo adiviné!");
        } else {
            learn();
        }
    }

    private void learn(){
        TreeNode wrongGuess = game.getCurrentNode();
        showMessage("\nNo logré adivinar.");
        String character = readValidText("¿En qué personaje estabas pensando? ");
        String question = readValidText("¿Qué pregunta distingue a " + character + " de " + wrongGuess.getData() + "? ");
        showMessage("Para " + character + ", ¿la respuesta es Sí o No?");
        game.learn(character, question, readYesNo());
        showSection("¡He aprendido un personaje nuevo! Árbol actualizado", tree.draw());
        saveTree();
    }

    private void saveTree() {
        if (tree.isEmpty()) {
            return;
        }
        try {
            csvManager.write(tree.serialize());
        } catch (UncheckedIOException e) {
            showMessage("No se pudo guardar el árbol: " + e.getMessage());
        }
    }

    private void showStatistics() {
        int characters = tree.countCharacters();
        int questions = tree.countQuestions();

        showMessage("\n--- ESTADÍSTICAS DEL ÁRBOL ---\n" +
                    "Soluciones/personajes: " + characters + "\n" +
                    "Interrogantes/preguntas: " + questions
        );
    }

    private void showTree() {
        if (tree.isEmpty()) {
            showMessage("El árbol está vacío.");
            return;
        }
        showSection("ÁRBOL", tree.draw());
        showSection("RECORRIDO PREORDEN", tree.preOrder());
        showSection("RECORRIDO INORDEN", tree.inOrder());
        showSection("RECORRIDO POSTORDEN", tree.postOrder());
    }

    private void resetTree() {
        showMessage("Se perderá lo aprendido. ¿Desea continuar?");
        if (!readYesNo()) {
            return;
        }
        try {
            tree.load(csvManager.reset());
            showMessage("El árbol volvió a su estado inicial.");
        } catch (IllegalArgumentException | UncheckedIOException e) {
            showMessage("No se pudo restablecer el árbol: " + e.getMessage());
        }
    }

    private boolean readYesNo(){
        String answer = readMessage("si/no: ").toLowerCase();
        while (!isYes(answer) && !isNo(answer)){
            answer = readMessage("Formato de respuesta inválido. Escriba si o no: ").toLowerCase();
        }
        return isYes(answer);
    }

    private boolean isYes(String answer) {
        return List.of("s", "si", "sí").contains(answer);
    }

    private boolean isNo(String answer) {
        return List.of("n", "no").contains(answer);
    }

    private String readValidText(String message) {
        String text = readMessage(message);
        while (text == null || text.isBlank() || text.contains(",")) {
            text = readMessage("Texto inválido (no vacío y sin comas). Intente de nuevo: ");
        }
        return text;
    }

    private void showSection(String title, DoublyLinked<String> lines) {
        showMessage("\n--- " + title + " ---");
        for (ListNode<String> node = lines.getHead(); node != null; node = node.getNext()) {
            showMessage(node.getData());
        }
    }

    public void showMessage(String message) {
        System.out.println(message);
    }

    public String readMessage(String message){
        System.out.println(message);
        return sc.nextLine().trim();
    }

    public int readInt(){
        try{
            return Integer.parseInt(readMessage("Opción: "));
        }catch (NumberFormatException e){
            return -1;
        }
    }
}
