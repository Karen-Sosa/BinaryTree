package co.edu.uptc.business;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class Manager {
    private final Tree tree;
    private TreeNode currentNode;

    public void start(){
        if (tree.isEmpty()){
            throw new IllegalStateException("No existe el juego.");
        }
        currentNode = tree.getRoot();
    }

    public boolean isCharacter(){
        return currentNode.isLeaf();
    }

    public void answer(boolean yes){
        if (isCharacter()) {
            throw new IllegalStateException("Ya se llegó a un personaje");
        }
        currentNode = yes? currentNode.getLeft() : currentNode.getRight();
    }

    public void learn(String character, String question, boolean answerForNew){
        if (!isCharacter()) {
            throw new IllegalArgumentException("Datos inválido, no es un personaje.");
        }
        TreeNode newCharacter = new TreeNode(character.trim());
        TreeNode newQuestion = new TreeNode(question.trim());
        newQuestion.setLeft(answerForNew ? newCharacter : currentNode);
        newQuestion.setRight(answerForNew ? currentNode : newCharacter);
        tree.replaceNode(currentNode, newQuestion);
        currentNode = newQuestion;
    }
}
